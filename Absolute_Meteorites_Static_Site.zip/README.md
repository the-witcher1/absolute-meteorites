# Absolute Meteorites — Static Version

This is the static web version of the Absolute Meteorites project.
It can be hosted instantly on GitHub Pages, Netlify, or any web host.

## 🚀 Deploy on GitHub Pages

1. Go to https://github.com/new and create a public repository (name: `absolute-meteorites`).
2. Upload the contents of this ZIP (especially `index.html`) to the repository.
3. Go to **Settings → Pages → Build and Deployment → Deploy from branch**.
4. Choose branch: `main`, folder: `/ (root)`.
5. Click **Save**.
6. Wait 1–2 minutes and open the link:
   https://YOUR-USERNAME.github.io/absolute-meteorites/

That’s your public link for the Global Award submission.
